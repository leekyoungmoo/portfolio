package com.belleange.mall.domain;

public enum ProductSellStatus {
    SELL, SOLD_OUT
}
