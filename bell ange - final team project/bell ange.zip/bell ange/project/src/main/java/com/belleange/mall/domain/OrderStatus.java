package com.belleange.mall.domain;

public enum OrderStatus {
    ORDER, CANCEL
}
