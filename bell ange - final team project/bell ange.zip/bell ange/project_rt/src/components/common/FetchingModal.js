import {RouletteSpinnerOverlay} from "react-spinner-overlay"


const FetchingModal = () => {
    return (

          <RouletteSpinnerOverlay />

    );
  };
export default FetchingModal;
