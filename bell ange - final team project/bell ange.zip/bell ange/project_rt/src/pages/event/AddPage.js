import AddComponent from "../../components/event/AddComponent";

const AddPage = () => {

  return ( 
  <div className="p-4 w-full bg-white">

    <AddComponent/> 

  </div>
   );
}
 
export default AddPage;

