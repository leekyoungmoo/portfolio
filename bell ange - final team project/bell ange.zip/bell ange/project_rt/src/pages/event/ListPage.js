import ListComponent from "../../components/event/ListComponent";


const ListPage = () => {


  return ( 
  <div className="p-4 w-full bg-white">

    <ListComponent/> 

  </div>
   );
}
 
export default ListPage;
