import Addcomponent from "../../components/products/AddComponent";


const AddPage = () => {


    return(
        <div className="w-full flex justify-center items-center m-0 p-2 border">
            <Addcomponent/>
        </div>
    )
}

export default AddPage;